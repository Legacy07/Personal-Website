<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">

    <!--    https://www.cloudways.com/blog/connect-mysql-with-php/-->
    <!--    https://madmimi.com/-->
    <!--    https://mailchimp.com/monkey-rewards/?utm_source=freemium_newsletter&utm_medium=email&utm_campaign=monkey_rewards&aid=ec607a78c8c22d43252e703bd&afl=1-->

    <?php
     include 'dbconnection.php';
 ?>

    <head>
        <!--     adapted to have a responsive design but not 100% of a mobile view from - https://webdesign.tutsplus.com/articles/quick-tip-dont-forget-the-viewport-meta-tag--webdesign-5972 -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- using the custom css -->    
        <!-- using the custom css -->    
        <link rel="stylesheet" href="../css/project_style.css"/>
        <link rel="stylesheet" href="../css/nav_bar.css"/>
        <link rel="stylesheet" href="../css/magnific-popup.css"/>
        <link rel="stylesheet" href="../css/footer.css"/>
        <link rel="shortcut icon" href="http://ahmetince.co.uk/logo.png" type="image/png" />

        <link rel="stylesheet" href="../css/subscribe_blog.css"/>
        <link href="https://fonts.googleapis.com/css?family=Montserrat|Poppins" rel="stylesheet">
        <script src="../js/nav_bar.js"></script>
        <script src="../js/back_to_top.js"></script>

        <!--        webgl libraries-->
        <script type="text/javascript" src="../js/three.js"></script>
        <script type="text/javascript" src="../js/jquery.js"></script>
        <script type="text/javascript" src="../js/stats.js"></script>
        <script src="../js/rotating_cube.js"></script>

        <!--        google analytics-->
        <script src="../js/google_analytics.js"></script>

        <title>Subscribe/UnSubscribe Blog</title>
    </head>

    <body>
        <!--        Navigation bar-->
        <div id="navigation">

        </div>
        <script> $(function() {
                $("#navigation").load("../nav_bar_diff_folders.html");
            });
        </script>

        <div class="subscribeBox">
            <form name="phpForm" action="unsubscribe.php"  method="post">

                <p>
                    If you've already subscribed, you can Unsubscribe here.
                </p>
                <input class="subscribeEmail" type="email" id="unsubscribe" name="unsubscribe" placeholder="Enter your e-mail" required>
                <input class="unSubscribeButton" type="submit" name="unsubscribeButton" value="Unsubscribe">

                <?php
                //if register button is succesfully clicked then send data from textboxes into these variables
                if (isset($_POST['unsubscribeButton']))
                {   
                    $eMail   = $_POST['unsubscribe'];

                    if ( !preg_match('/^([\w\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/',$eMail) ){
                        echo "Please enter a valid e-mail";
                    }
                    else{

                        //finding confirmed emails
                        $emails = mysqli_query($conn, "SELECT * FROM test_blog_subs where email='$eMail'");
                        //return the rows of the search
                        $rows = mysqli_affected_rows($conn);
                        //if any email is found then output a message 
                        if($rows >=1){
                            mysqli_query($conn, "DELETE FROM test_blog_subs WHERE email = '$eMail'")
                                or die(mysql_error()); 
                            echo "<p> $eMail </p>";
                            echo "<p>Successfully unsubscribed.</p>";

                        }
                        else{
                            echo "<p> $eMail </p>";
                            echo "<p>hasn't got any subscription.</p>";

                        }
                    }
                }

                //close connection
                mysqli_close($conn);

                ?>
            </form>
        </div>

        <!--footer-->
        <!--
<div id="footer">
</div>
<script> 
$(function() {
$("#footer").load("../footer_diff_folders.html");
});
</script>
-->



        <!-- jQuery 1.7.2+ or Zepto.js 1.0+ -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

        <button onclick="autoScrollFunction()" id="autoScrollButton">Back to top</button>

    </body>
</html>