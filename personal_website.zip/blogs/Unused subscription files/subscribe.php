<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">

    <!--    https://www.cloudways.com/blog/connect-mysql-with-php/-->
    <!--    https://madmimi.com/-->
    <!--    https://mailchimp.com/monkey-rewards/?utm_source=freemium_newsletter&utm_medium=email&utm_campaign=monkey_rewards&aid=ec607a78c8c22d43252e703bd&afl=1-->

    <?php
  include 'dbconnection.php';
?>

    <head>
        <!--     adapted to have a responsive design but not 100% of a mobile view from - https://webdesign.tutsplus.com/articles/quick-tip-dont-forget-the-viewport-meta-tag--webdesign-5972 -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- using the custom css -->    
        <!-- using the custom css -->    
        <link rel="stylesheet" href="../css/project_style.css"/>
        <link rel="stylesheet" href="../css/nav_bar.css"/>
        <link rel="stylesheet" href="../css/magnific-popup.css"/>
        <link rel="stylesheet" href="../css/footer.css"/>
        <link rel="shortcut icon" href="http://ahmetince.co.uk/logo.png" type="image/png" />

        <link rel="stylesheet" href="../css/subscribe_blog.css"/>
        <link href="https://fonts.googleapis.com/css?family=Montserrat|Poppins" rel="stylesheet">
        <script src="../js/nav_bar.js"></script>
        <script src="../js/back_to_top.js"></script>

        <!--        webgl libraries-->
        <script type="text/javascript" src="../js/three.js"></script>
        <script type="text/javascript" src="../js/jquery.js"></script>
        <script type="text/javascript" src="../js/stats.js"></script>
        <script src="../js/rotating_cube.js"></script>

        <!--        google analytics-->
        <script src="../js/google_analytics.js"></script>

        <title>Subscribe/UnSubscribe Blog</title>
    </head>

    <body>
        <!--        Navigation bar-->
        <div id="navigation">

        </div>
        <script> $(function() {
                $("#navigation").load("../nav_bar_diff_folders.html");
            });
        </script>


        <!--            Subscribe for blog-->
        <div class="subscribeBox">
            <form name="phpForm" action="subscribe.php" method="post">
                <p>
                    Subscribe to my Blog posts
                </p>
                <input class="subscribeEmail" type="email" id="subscribe" name="subscribe" placeholder="Enter your e-mail" required>
                <input class="subscribeButton" type="submit" name="subscribeButton" value="Subscribe">

                <?php
                //if register button is succesfully clicked then send data from textboxes into these variables
                if (isset($_POST['subscribeButton']))
                {   
                    $eM   = $_POST['subscribe'];
                    $notConfirmed = 0;


                    if ( !preg_match('/^([\w\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/',$eM) ){
                        echo "Please enter a valid e-mail";
                    }
                    else{

                        //options for bcrypt uses blowfish encryption, including salt for improving encryption.
                        $options = [
                            'cost' => 11,
                        ];
                        //hash the email 
                        $hashEmail = password_hash($eM, PASSWORD_BCRYPT, $options);

                        //DO; if email is found and its confirmed then output else if the email is found but not confirmed then also output a message]

                        //finding confirmed emails
                        $emails = mysqli_query($conn, "SELECT * FROM test_blog_subs where email='$eM' And isEmailConfirmed= 1");
                        //return the rows of the search
                        $rows = mysqli_affected_rows($conn);
                        //if any email is found then output a message 
                        if($rows >=1){
                            //                            echo '<script type="text/javascript">
                            //                                                        alert("This email is already subscribed.");
                            //                                                        </script>';
                            echo "<p>This e-mail is already subscribed!<p/>";

                            //                            echo '<script language="javascript">
                            //                                        var whitebg = document.getElementById("white-background");
                            //                                        var dlg = document.getElementById("dialogBox");
                            //                                        whitebg.style.display = "block";
                            //                                        dlg.style.display = "block";
                            //                                        var winWidth = window.innerWidth;
                            //                                        dlg.style.left = (winWidth/2) - 480/2 + "px";
                            //                                        dlg.style.top = "150px";
                            //                                    </script>
                            //                                    ';
                        }
                        //finding unconfirmed emails
                        $emails2 = mysqli_query($conn, "SELECT * FROM test_blog_subs where email='$eM' And isEmailConfirmed= 0");
                        //return the rows of the search
                        $rows2 = mysqli_affected_rows($conn);
                        //if any email is found without confirmed then output a message 
                        if($rows2 >=1){

                            $foundEmailHash = mysqli_query($conn, "SELECT emailHash FROM test_blog_subs WHERE Email='$eM'");  
                            $foundHash = mysqli_fetch_assoc($foundEmailHash);
                            $emailHash = $foundHash['emailHash'];


                            //adapted to send an email with dynamically created website from - https://code.tutsplus.com/tutorials/how-to-implement-email-verification-for-new-members--net-3824

                            //Sending email with verificaiton link 
                            $to      = $eM; // email of the registered member
                            $subject = 'E-mail Confirmation for ahmetince.co.uk/blog'; 
                            $body =
                                'Hi there,

In order to complete the subscription, please click on the link below to confirm your e-mail address and start receiving my weekly blog posts.                             

Please click on this link to confirm:
http://ahmetince.co.uk/blogs/email_activation.php?email_address='.$eM.'&email_hash='.$emailHash.'';

                            $headers = 'From: ahmetince@ahmetince.co.uk' . "\r\n"; // headers
                            $status = mail($to, $subject, $body, $headers); // Sending email

                            if($status)
                            { 
                                echo '<p style="color:green;">A confirmation e-mail including a link has been sent to </p>';
                                echo "<p> $eM </p>";
                            } else { 
                                //                                echo '<script language="javascript">
                                //                                        var whitebg = document.getElementById("white-background");
                                //                                        var dlg = document.getElementById("dialogBox");
                                //                                        whitebg.style.display = "block";
                                //                                        dlg.style.display = "block";
                                //                                        var winWidth = window.innerWidth;
                                //                                        dlg.style.left = (winWidth/2) - 480/2 + "px";
                                //                                        dlg.style.top = "150px";
                                //                                    </script>
                                //                                    ';
                                echo '<p style="color:red;">Something went wrong, Please try again!</p>'; 
                            }
                        }

                        //no emails
                        $emails3 = mysqli_query($conn, "SELECT * FROM test_blog_subs where email='$eM'");
                        //return the rows of the search
                        $rows3 = mysqli_affected_rows($conn);
                        //                        else if
                        //if not insert the data in table
                        if($rows3 <= 0){
                            //insert values into rows
                            $sql = mysqli_query($conn, "INSERT INTO test_Blog_Subs (email, emailHash, isEmailConfirmed)
                            VALUES ('$eM','$hashEmail', '0')");

                            //adapted to send an email with dynamically created website from - https://code.tutsplus.com/tutorials/how-to-implement-email-verification-for-new-members--net-3824

                            //Sending email with verificaiton link 
                            $to      = $eM; // email of the registered member
                            $subject = 'E-mail Confirmation for ahmetince.co.uk/blog'; 
                            $body =
                                'Hi there,

In order to complete the subscription, please click on the link below to confirm your e-mail address and start receiving my weekly blog posts.                             

Please click on this link to confirm:
http://ahmetince.co.uk/blogs/email_activation.php?email_address='.$eM.'&email_hash='.$hashEmail.'';

                            $headers = 'From: ahmetince@ahmetince.co.uk' . "\r\n"; // headers
                            $status = mail($to, $subject, $body, $headers); // Sending email

                            if($status)
                            { 
                                echo '<p style="color:green;">A confirmation e-mail including a link has been sent to </p>';
                                echo "<p> $eM </p>";
                            } else { 
                                //                                echo '<script language="javascript">
                                //                                        var whitebg = document.getElementById("white-background");
                                //                                        var dlg = document.getElementById("dialogBox");
                                //                                        whitebg.style.display = "block";
                                //                                        dlg.style.display = "block";
                                //                                        var winWidth = window.innerWidth;
                                //                                        dlg.style.left = (winWidth/2) - 480/2 + "px";
                                //                                        dlg.style.top = "150px";
                                //                                    </script>
                                //                                    ';
                                echo '<p style="color:red;">Something went wrong, Please try again!</p>'; 
                            }
                        }
                    }
                }

                //close connection
                mysqli_close($conn);

                ?>
            </form>
        </div>

        <!--footer-->
        <!--
<div id="footer">
</div>
<script> 
$(function() {
$("#footer").load("../footer_diff_folders.html");
});
</script>
-->



        <!-- jQuery 1.7.2+ or Zepto.js 1.0+ -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

        <button onclick="autoScrollFunction()" id="autoScrollButton">Back to top</button>

    </body>
</html>