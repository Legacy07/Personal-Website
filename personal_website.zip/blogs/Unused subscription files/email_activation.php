<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">

      <?php
     include 'dbconnection.php';
 ?>
    <head>
        <!--     adapted to have a responsive design but not 100% of a mobile view from - https://webdesign.tutsplus.com/articles/quick-tip-dont-forget-the-viewport-meta-tag--webdesign-5972 -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- using the custom css -->    
        <link rel="stylesheet" href="../css/project_style.css"/>
        <link rel="stylesheet" href="../css/nav_bar.css"/>
        <link rel="stylesheet" href="../css/magnific-popup.css"/>
        <link rel="stylesheet" href="../css/footer.css"/>
        <link rel="shortcut icon" href="http://ahmetince.co.uk/logo.png" type="image/png" />

        <link rel="stylesheet" href="../css/subscribe_blog.css"/>
        <link href="https://fonts.googleapis.com/css?family=Montserrat|Poppins" rel="stylesheet">
        <script src="../js/nav_bar.js"></script>
        <script src="../js/back_to_top.js"></script>

        <!--        webgl libraries-->
        <script type="text/javascript" src="../js/three.js"></script>
        <script type="text/javascript" src="../js/jquery.js"></script>
        <script type="text/javascript" src="../js/stats.js"></script>
        <script src="../js/rotating_cube.js"></script>

        <!--        google analytics-->
        <script src="../js/google_analytics.js"></script>

        <title>Email Activation</title>

        <?php
    header('Refresh: 5; URL=http://ahmetince.co.uk/blog.html');
        ?>
    </head>
    <body>

        <!--        Navigation bar-->
        <div id="navigation">

        </div>
        <script> $(function() {
                $("#navigation").load("nav_bar_diff_folders.html");
            });
        </script>


        <div>
            <?php
            //declaring variables
            $output = "";
            $header = "";
 
            //adapted to activate the email address from - https://code.tutsplus.com/tutorials/how-to-implement-email-verification-for-new-members--net-3824


            //if email address is in the url and not empty and if email hash is in the url and not empty then verify the email address
            if(isset($_GET['email_address']) && !empty($_GET['email_address']) AND isset($_GET['email_hash']) && !empty($_GET['email_hash'])){
                // Verify data
                //Getting it off url by removing email address string and gets the actual email address and hash of that user
                $email_address = mysqli_real_escape_string($conn, $_GET['email_address']);
                $email_hash = mysqli_real_escape_string($conn, $_GET['email_hash']); // Set hash variable

                //email address and if verified is 0 then find the address
                $search = mysqli_query($conn, "SELECT Email, isEmailConfirmed FROM test_blog_subs WHERE Email='$email_address' AND emailHash='$email_hash' AND isEmailConfirmed='0'") or die(mysqli_error($conn)); 
                //find the matching rows
                $match  = mysqli_num_rows($search);

                //if there is a matching result of more than 1 then activate, because a user can have multiple email addresses to sign up with a different username but email hash comes into play to avoid any confusion in usernames and email addresses
                if($match > 0){
                    // Activate the account
                    mysqli_query($conn, "UPDATE test_blog_subs SET isEmailConfirmed = 1 WHERE Email='$email_address'AND emailHash='$email_hash'") or die(mysqli_error($conn));
                    $output = "Your e-mail has been verified. You will be receiving weekly blog posts from now on.";
                    $header = "Congratulations!";

                }else{
                    // Invalid url or account has already been activated.
                    $output = "The url may be invalid or the account was previously verified. Try to copy and paste the link instead.";
                    $header = "Error occured!";

                }

            }else{
                // Invalid approach
                $output = "Please click on the link again.";
                $header = "Error occured!";

            }
            ?>

            <div class="header"><p><?php echo $header ?></p></div>
            <div class="activatedBox"><p><?php echo $output ?></p></div>
            <p><?php echo "Redirecting in 5 seconds" ?></p>
        </div>
    </body>
</html>