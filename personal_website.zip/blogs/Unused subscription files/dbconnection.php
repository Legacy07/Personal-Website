<?php
// Database Connection 
$conn = mysqli_connect("localhost","ahmet871_blog","Mertmert2004","ahmet871_BlogDB");
//$conn = mysqli_connect("localhost","root","","test");

if (mysqli_connect_errno($conn)) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
} ?>
