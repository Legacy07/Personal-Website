<?php
 
class DB_Functions {
 
    private $conn;
 
    // constructor
    function __construct() {
        require_once 'connection.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }
 
    // destructor
    function __destruct() {
         
    }
 
    /**
     * Storing new user
     * returns user details
     */
    public function storeUser($accountName, $email, $password) {
        $uuid = uniqid('', true);
 
        $stmt = $this->conn->prepare("INSERT INTO Accounts(AccountId, AccountName, Email, Password) VALUES(?, ?, ?, ?)");
        $stmt->bind_param("ssss", $uuid, $accountName, $email, $password);
        $result = $stmt->execute();
        $stmt->close();
 
        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM Accounts WHERE Email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
 
            return $user;
        } else {
            return false;
        }
    }
 
    /**
     * Get user by email and password
     */
    public function getUserByEmailAndPassword($email, $password) {
 
        $stmt = $this->conn->prepare("SELECT * FROM Accounts WHERE email = ?");
 
        $stmt->bind_param("s", $email);
 
        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
 
//            // verifying user password
//            $salt = $user['salt'];
//            $encrypted_password = $user['encrypted_password'];
//            $hash = $this->checkhashSSHA($salt, $password);
            // check for password equality
//            if ($encrypted_password == $hash) {
//                // user authentication details are correct
//                return $user;
//            }
//        } else {
//            return NULL;
//        }
    }
 
    /**
     * Check user is existed or not
     */
    public function isUserHasSameEmail($email) {
        $stmt = $this->conn->prepare("SELECT Email from Accounts WHERE Email = ?");
 
        $stmt->bind_param("s", $email);
 
        $stmt->execute();
 
        $stmt->store_result();
 
        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }
    
    /**
     * Check if there are any existing account names
     */    
     public function isUserHasSameAccountName($accountName) {
        $stmt = $this->conn->prepare("SELECT AccountName from Accounts WHERE AccountName = ?");
 
        $stmt->bind_param("s", $accountName);
 
        $stmt->execute();
 
        $stmt->store_result();
 
        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }
 
}
 
?>