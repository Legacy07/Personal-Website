<?php
// class DB_Connect {
//     private $conn;
 
//     // Connecting to database
//     public function connect() {
//         require_once 'include/config.php';
         
//         // Connecting to mysql database
//         $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
         
//         // return database handler
//         return $this->conn;
//     }
// }


error_reporting(E_ALL);
ini_set('display_errors', 1);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "technical_iq_test";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}
 
?>