<?php

// require_once 'include/db_functions.php';
// $db = new DB_Functions();

// // json response array
// $response = array("error" => FALSE);

// if (isset($_POST['accountName']) && isset($_POST['email']) && isset($_POST['password'])) {

//     // receiving the post params
//     $accountName = $_POST['accountName'];
//     $email = $_POST['email'];
//     $password = $_POST['password'];

//     // check if user is already existed with the same email
//     if ($db->isUserHasSameEmail($email)) {
//         // user already existed
//         $response["error"] = TRUE;
//         $response["error_msg"] = "User already existed with " . $email;
//         echo json_encode($response);
//     } 
    
//      // check if user is already existed with the same account name
//     if ($db->isUserHasSameAccountName($accountName)) {
//         // user already existed
//         $response["error"] = TRUE;
//         $response["error_msg"] = "User already existed with " . $accountName;
//         echo json_encode($response);
//     } 
    
//     else {
//         // create a new user
//         $account = $db->storeUser($accountName, $email, $password);
//         if ($account) {
//             // user stored successfully
//             $response["error"] = FALSE;
            
//             $response["accounts"]["accountId"] = $account["accountId"];
//             $response["accounts"]["accountName"] = $account["accountName"];
//             $response["accounts"]["email"] = $account["email"];
//             $response["accounts"]["password"] = $account["password"];
//             echo json_encode($response);
//         } else {
//             // user failed to store
//             $response["error"] = TRUE;
//             $response["error_msg"] = "Unknown error occurred in registration!";
//             echo json_encode($response);
//         }
//     }
// } else {
//     $response["error"] = TRUE;
//     $response["error_msg"] = "Required parameters (Account name, email or password) is missing!";
//     echo json_encode( );
// }

error_reporting(E_ALL);
ini_set('display_errors', 1);
if(isset($_POST['email']) && !empty(isset($_POST['email'])) 
&& isset($_POST['password']) && !empty(isset($_POST['password']))
&& isset($_POST['accountName']) && !empty(isset($_POST['accountName']))){ 
  include_once("connection.php");
  $uuid = uniqid('', true); 
  $accountName = $_POST['accountName']; 
  $email = $_POST['email']; 
  $password = $_POST['password']; 
  $sql = "INSERT INTO accounts VALUES ('$uuid', '$accountName', '$email', '$password')"; 
  if ($conn->query($sql) === TRUE) { 
    $last_id = mysqli_insert_id($conn); 
    echo "$last_id"; 
  } else { 
    echo "ErrorInsert"; 
    echo "Error: " . $sql . "<br>" . $conn->error; 
  }
}
?>