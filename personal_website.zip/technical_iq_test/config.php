<?php
 
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "ahmet871_iqTest");
define("DB_PASSWORD", "Mertmert2004");
define("DB_DATABASE", "ahmet871_technicalIQTest");
?>